import { LightningElement, api } from "lwc";

export default class Form extends LightningElement {
  fname="";
  lname="";
  address1="";
  address2="";
  city="";
  zipcode="";
  phone="";

}