import { LightningElement } from "lwc";

export default class App extends LightningElement {
  
showfeatures=true;
showfeaturesb=true;
showfeaturesc=true;
  
  get returnButton() {
    return [
      {
        buttonlabel:"Home",
        link:"https://webcomponents.dev/edit/AYd5n2COmFjzMJcjilAT/src/app.js?p=stories",
      },
      {
        buttonlabel: "Listings",
        link:"https://webcomponents.dev/edit/X0S89WQsOuj0YAvv9L6C/src/app.css?p=stories",
      },
      {
        buttonlabel:"MLS Search",
        link:"https://webcomponents.dev/edit/nHIq9eAgZGZ9zIRcJECo/src/app.css?p=stories",
        },
      {
      buttonlabel:"Agents",
      link:"https://webcomponents.dev/edit/jLbbi6lcyopqgsDIOzKS/src/app.css?p=stories",
      },
      {
        buttonlabel:"Contact Us",
        link:"https://webcomponents.dev/edit/UfotYbVjXC6yLbWzka7T/src/app.html?p=stories",
      }

    ];
  }
}