import { LightningElement, api } from "lwc";

export default class Navigation extends LightningElement {
  @api
  buttonlabel = "";
  @api
  link="";}